import numpy as np
import matplotlib.pyplot as plt

# 设置随机种子，以保证结果可重复
np.random.seed(0)

# 生成 5000 个从标准高斯分布中采样的一维数据 X
X = np.random.normal(loc=0, scale=1, size=5000)

# 根据 Y = 2*X + b 生成 Y，其中 b ~ N(0, 4)
b = np.random.normal(loc=0, scale=2, size=5000)  # 方差为 4，即标准差为 2
Y = 4 * X + b

# 1. 计算 Y 的方差
variance_Y = np.var(Y)
print(f"Variance of Y: {variance_Y}")

# 2. 计算 [X, Y]^T 的协方差矩阵
cov_matrix = np.cov(X, Y)
print("Covariance Matrix:\n", cov_matrix)

# 计算协方差矩阵主对角线和副对角线元素的来源
# 协方差矩阵的主对角线是方差：
# var(X) = np.var(X)
# var(Y) = np.var(Y)
# 副对角线是协方差：
# cov(X, Y) = np.cov(X, Y)[0, 1] = np.cov(X, Y)[1, 0]

# 3. 特征分解
eigvals, eigvecs = np.linalg.eig(cov_matrix)
print("Eigenvalues:", eigvals)
print("Eigenvectors:\n", eigvecs)

# 4. 绘制特征向量方向
# 使用特征值的平方根的二倍作为特征向量模长
eigvec1 = eigvecs[:, 0]
eigvec2 = eigvecs[:, 1]
eigvec1_scaled = eigvec1 * np.sqrt(eigvals[0]) * 2
eigvec2_scaled = eigvec2 * np.sqrt(eigvals[1]) * 2

# 5. 绘制椭圆
# 计算特征向量的反正切来得到角度
theta = np.arctan2(eigvec1[1], eigvec1[0])  # 角度
# 使用特征值的平方根的四倍作为椭圆的长轴和短轴长度
major_axis = np.sqrt(eigvals[0]) * 4
minor_axis = np.sqrt(eigvals[1]) * 4

# 绘制散点图和特征向量
plt.figure(figsize=(8, 8))
plt.scatter(X, Y, alpha=0.5, s=5)

plt.quiver(0, 0, eigvec1_scaled[0], eigvec1_scaled[1], angles='xy', scale_units='xy', scale=1, color='r', label='Eigenvector 1')
plt.quiver(0, 0, eigvec2_scaled[0], eigvec2_scaled[1], angles='xy', scale_units='xy', scale=1, color='b', label='Eigenvector 2')
# plt.figure(figsize=(8, 8))

# plt.quiver(0, 0, eigvecs[0, 0], eigvecs[1, 0], angles='xy', scale_units='xy', scale=1, color='r', label='Eigenvector 1')
# plt.quiver(0, 0, eigvecs[0, 1], eigvecs[1, 1], angles='xy', scale_units='xy', scale=1, color='b', label='Eigenvector 2')
plt.axis('equal')
plt.axhline(0, color='black',linewidth=0.5)
plt.axvline(0, color='black',linewidth=0.5)

# 绘制椭圆
ellipse = plt.matplotlib.patches.Ellipse((0, 0), major_axis, minor_axis, angle=np.degrees(theta), color='g', fill=False, linestyle='--')
plt.gca().add_patch(ellipse)

plt.title('2D Covariance Matrix and Ellipse')
plt.xlabel('X')
plt.ylabel('Y')
plt.grid(True)
plt.legend()

# 显示图形
plt.show()
