#include <iostream>
#include <kindr/Core>
#include <Eigen/Dense>

int main() {
  using namespace kindr;
  using namespace Eigen;

  // ----------------------------
  // 1. 定义 A → B 的旋转（被动旋转，绕 Z 轴 +90°）
  // ----------------------------
  double angle_rad = M_PI / 2.0; // +90 degrees in radians

  // 使用 Eigen 直接构造旋转矩阵
  Matrix3d R_AB_active;
  R_AB_active = AngleAxisd(angle_rad, Vector3d::UnitZ()).toRotationMatrix(); // 主动旋转矩阵

  // 被动旋转矩阵 R_BA 是主动的转置
  Matrix3d R_BA_passive = R_AB_active.transpose();

  // 转换为 Kindr 旋转矩阵
  RotationMatrixD R_BA_kindr(R_BA_passive);

  std::cout << "被动旋转 R_BA (A系 → B系):\n" << R_BA_passive << "\n\n";

  // ----------------------------
  // 2. 向量 Ar_CD: 向量从 C 指向 D，在 A 系中表示
  // ----------------------------
  Vector3d Ar_CD(1.0, 0.0, 0.0); // 沿 A 的 X 轴方向

  // ----------------------------
  // 3. 使用被动旋转矩阵将其转换到 B 系
  // ----------------------------
  // Vector3d Br_CD = R_BA_kindr * Ar_CD;
  Vector3d Br_CD = R_BA_kindr.matrix() * Ar_CD;


  std::cout << "Ar_CD 向量在 A 系中表示: " << Ar_CD.transpose() << std::endl;
  std::cout << "Br_CD 向量在 B 系中表示: " << Br_CD.transpose() << std::endl;

  // ----------------------------
  // 4. Kindr 与 Eigen 验证一致性
  // ----------------------------
  // Kindr to Eigen
  Matrix3d R_eigen_check = R_BA_kindr.toImplementation();
  std::cout << "\nKindr 转 Eigen 矩阵验证:\n" << R_eigen_check << std::endl;

  return 0;
}
