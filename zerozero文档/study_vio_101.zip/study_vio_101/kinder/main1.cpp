#include <iostream>
#include <kindr/Core>
// #include <kindr/rotations/RotationEigenConverter.hpp>

using namespace kindr;

int main() {
    // 1. 旋转表示相互转换
    std::cout << "===== 旋转表示转换 =====" << std::endl;
    // 创建绕Z轴90°的旋转
    AngleAxisD angleAxis(M_PI/2, Eigen::Vector3d::UnitZ());
    
    // 转换为其他表示
    EulerAnglesZyxD euler(angleAxis);
    RotationQuaternionD quaternion(angleAxis);
    RotationMatrixD rotationMatrix(quaternion);  // 通过四元数创建旋转矩阵

    std::cout << "轴角: " << angleAxis << std::endl;
    std::cout << "欧拉角(ZYX): " << euler << std::endl;
    std::cout << "四元数: " << quaternion << std::endl;
    std::cout << "旋转矩阵:\n" << rotationMatrix.matrix() << std::endl;

    // 2. 向量旋转操作
    std::cout << "\n===== 向量旋转 =====" << std::endl;
    Eigen::Vector3d vector(1, 0, 0);
    
    // 使用不同表示旋转向量
    Eigen::Vector3d rotatedByMatrix = rotationMatrix.rotate(vector);
    Eigen::Vector3d rotatedByQuat = quaternion.rotate(vector);
    Eigen::Vector3d rotatedByAngleAxis = angleAxis.rotate(vector);
    
    std::cout << "原始向量: " << vector.transpose() << std::endl;
    std::cout << "矩阵旋转: " << rotatedByMatrix.transpose() << std::endl;
    std::cout << "四元数旋转: " << rotatedByQuat.transpose() << std::endl;
    std::cout << "轴角旋转: " << rotatedByAngleAxis.transpose() << std::endl;

    // 3. 与Eigen互操作
    std::cout << "\n===== Eigen互操作 =====" << std::endl;
    Eigen::Matrix3d eigenMatrix = rotationMatrix.matrix();
    
    // 正确转换Kindr四元数到Eigen四元数
    Eigen::Quaterniond eigenQuat(
        quaternion.w(), 
        quaternion.x(), 
        quaternion.y(), 
        quaternion.z()
    );
    
    // Eigen到Kindr的转换
    RotationMatrixD kindrMatrix(eigenMatrix);
    RotationQuaternionD kindrQuat(eigenQuat);
    
    std::cout << "Eigen旋转矩阵:\n" << eigenMatrix << std::endl;
    std::cout << "转换回的Kindr矩阵:\n" << kindrMatrix.matrix() << std::endl;
    std::cout << "Eigen四元数: ("
              << eigenQuat.w() << ", "
              << eigenQuat.x() << ", "
              << eigenQuat.y() << ", "
              << eigenQuat.z() << ")\n";
    std::cout << "Kindr四元数: " << kindrQuat << std::endl;

    // 4. 任务1示例实现
    std::cout << "\n===== 任务1示例 =====" << std::endl;
    // NED坐标系下绕Z轴旋转90°的被动旋转
    // 正确创建旋转矩阵：先创建轴角或四元数，再转换为旋转矩阵
    AngleAxisD rotationAA(M_PI/2, Eigen::Vector3d::UnitZ());
    RotationMatrixD R_BA(rotationAA);
    
    Eigen::Vector3d ArCD(1, 0, 0); // A系中的向量（指向北）
    Eigen::Vector3d BrCD = R_BA.rotate(ArCD); // 使用rotate()进行被动旋转
    
    std::cout << "R_BA:\n" << R_BA.matrix() << std::endl;
    std::cout << "A系向量: " << ArCD.transpose() << std::endl;
    std::cout << "B系表示: " << BrCD.transpose() << std::endl;

    return 0;
}